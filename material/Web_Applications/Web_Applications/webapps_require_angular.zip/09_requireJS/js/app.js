requirejs.config({
    "baseUrl": "js",
    "paths": {
        "jquery": [
            "http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min",
            "jquery"
        ]
    }
});

requirejs(["jquery",
            "modules/module1"], function ($, module1) {

	module1.init();
});