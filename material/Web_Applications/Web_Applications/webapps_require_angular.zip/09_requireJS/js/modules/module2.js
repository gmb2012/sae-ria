define(["jquery"], function ($) {
    return {
        init : function(){
			console.log("Hallo ich bin das 2. Module");
        }
    };
});