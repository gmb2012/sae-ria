define(["jquery", "modules/module2"], function ($, module2) {
    return {
        init : function(){
			console.log("Test");
			this.setModule2();
        },
        setModule2 : function(){
			module2.init();
        }
    };
});