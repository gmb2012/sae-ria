function MainController($scope){
	$scope.frameworks = ['AngularJS', 'BackboneJS'];

	$scope.addFramework = function(){
		$scope.frameworks.push($scope.newFramework);
		$scope.newFramework = ''; 
	};
}