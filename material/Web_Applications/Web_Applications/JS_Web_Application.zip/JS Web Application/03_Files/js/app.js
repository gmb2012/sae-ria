$(document).ready(function(){
    $('#files').on('change', function(evt){
        var files = evt.target.files;
        var output = '';

        for(var i = 0, f; f = files[i]; i++){
            output += '<li><strong>'+f.name+'</strong> (' + f.type + ') - ' + f.size + ' Bytes, Zuletzt geändert: '+ f.lastModifiedDate.toLocaleDateString() + ' </li>';
        }
        $('#list').html('<ul>'+output+'</ul>');
    });
});