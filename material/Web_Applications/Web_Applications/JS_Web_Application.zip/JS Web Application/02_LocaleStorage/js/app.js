$(document).ready(function(){
    var ls = window.localStorage;

    loadColor();

    function saveColor(bgColor, conBgColor){
        ls.setItem('bodyBackgroundColor', bgColor);
        ls.setItem('contentBackgroundColor', conBgColor);
    }

    function loadColor(){
        var loadedBgColor = ls.getItem('bodyBackgroundColor');
        var loadedConBgColor = ls.getItem('contentBackgroundColor');

        $('html, body').css('background', loadedBgColor);
        $('#Wrapper').css('background', loadedConBgColor);
    }


    $('#submitMessage').click(function(){
        var bgColor = $('#bgColor').val();
        var conBgColor = $('#conBgColor').val();

        saveColor(bgColor, conBgColor);

        return false;
    });
});
