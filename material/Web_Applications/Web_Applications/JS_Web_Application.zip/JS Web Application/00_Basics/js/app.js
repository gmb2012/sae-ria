var meineVariable = "Hallo ich bin eine Variable";
var meineNumber = 200;
var trueOrFalse = true;


/*var meineFunction = function(){
    return "Hallo";
}

console.log(meineFunction());

function meineFunction(){
    var meineZweiteVariable = "Ich bin die zweite";

};*/


/*var werBistDu = function(name){
    if(typeof name === "undefined"){
        console.log("Du hast keinen Namen angegeben");
    } else {
        console.log("Hallo " + name);
    }
};
werBistDu("Günther");*/


/*var meinObject = {};

meinObject.name = "Günther";

meinObject.move = function(){
    alert("Move move move");
};

console.log(meinObject.name);

if(meinObject.name === "Günther"){

}

meinObject.move();*/



document.getElementById('klickBtn').onclick = function(){

    var meinName = document.getElementById('name').value;
    console.log(meinName);

    return false;
}












