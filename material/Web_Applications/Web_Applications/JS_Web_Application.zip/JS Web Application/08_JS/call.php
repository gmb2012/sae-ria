<?php

    $meinArray = array("Vorname" => "Stefan", "Nachname" => "Feser");

    //print_r($meinArray);

    $jsonData = json_encode($meinArray);

    print $jsonData;

?>