/*var bully = new Object();

bully.tires = 4;
bully.colour = "red";
bully.doors = 5;
bully.running = true;

bully.getStatus = function(){
	return bully.running;
};

console.log(bully.getStatus()); */

/*var myObject = new Object();

myObject.tires = 4;

myObject['0'] = 'f';
myObject['1'] = 'o';
myObject['2'] = 'o';

console.log(myObject);

var myString = new String('foo');
console.log(myString);*/

/*
function helloIamAFunction(){
	console.log(this);
}

helloIamAFunction();*/

/*var Car = function(tires, colour, doors, running){
	this.tires = tires;
	this.colour = colour;
	this.doors = doors;
	this.running = running;
	this.getStatus = function(){
		return this.running;
	};

//console.log(this);
};

var bully = new Car(4, "red", 5, true);
var smart = new Car(4, "green", 3, false);

console.log(smart.getStatus());

console.log(bully);
console.log(smart);*/


/*var Car = function(tires, colour, doors, running){
	this.tires = tires;
	this.colour = colour;
	this.doors = doors;
	this.running = running;
	this.getStatus = function(){
		return this.running;
	};

//console.log(this);
};

var bully = new Car(4, "red", 5, true);


var bully2 = new Object();

bully2.tires = 4;
bully2.colour = "red";
bully2.doors = 5;
bully2.running = true;

bully2.getStatus = function(){
	return bully2.running;
};

console.log(bully);
console.log(bully2); 

String();
Object();
Function();
Number();
Array();
Date();
Boolean();
RegExp();
Error();

var time = new Date();
console.log(time.getMonth());

*/

/*
var myArrayLiteral = [];
var myArray = new Array();

var myObjectLiteral = {};
var myObject = new Object();

var myString = new String("Hallo");
var myStringLiteral = "Hallo";

var myBoo = new Boolean(false);
var myBooLiteral = true;

/*var myFunction = new Function(x,y);
var myFunctionLiteral = function(x,y){
};

console.log(typeof myBoo, typeof myBooLiteral);


var myNull = null;
var myUndefined = undefined;

console.log(irgendeineVariable);


var myObject = {
	myString : "Hallo",
	myNumber : 2,
	myBoolean : false
};*/


// Verschachtelte Objekte:

/*var myObject1 = {
	myObject1_1 : {
		myObject1_1_1:{foo:'bar'},
		myObject1_1_2:{}
	},
	myObject1_2 : {
		objectNr: 2
	}
};

console.log(myObject1.myObject1_1.myObject1_1_1.foo);*/


// Delete

/*var foo = {bar: 'bar'};
delete foo.bar;

console.log('bar' in foo);*/



// Vererbung / Prototyping

/*var myObject = {};

Object.prototype.bla = "test";

myObject.bla = "tesdawd";

console.log(myObject.bla);

var myOtherObject = {};

console.log(myOtherObject.bla);*/


/*var myArray = new Array();

myArray[0] = 'foo';
myArray[1] = 'bar';

myArray.tolleMethode = function(){
	return "bla"
}



console.log(myArray.hasOwnProperty('tolleMethode'));*/


/*var stefan = {
	vorname : "stefan",
	nachname : "feser",
	age : 26
};

for(var key in stefan) {
	if(stefan.hasOwnProperty(key)){
		//console.log(key);
	}
}


Date.prototype.ostern = function(){
	return '09. April';
};


var now = new Date();
var eastern = now.ostern();
console.log(eastern);*/



/*var Car = function(tires, colour, doors, running){
	this.tires = tires;
	this.colour = colour;
	this.doors = doors;
	this.running = running;
	this.getStatus = function(){
		return this.running;
	};
};

Car.prototype.bounce = function(){
	return 'bounce bounce bounce';
};


var beetle = new Car(4, "red", 5, false);
var currentStatus = beetle.getStatus();

//console.log(currentStatus);

var lowRiderVonOlaf = new Car();
var lowRiderVonAngelo = new Car(4, 'black', 4, true);



console.log(lowRiderVonAngelo.bounce());

console.log(lowRiderVonOlaf.bounce());
console.log(beetle.bounce());*/




/*
var Car = function(tires, colour, doors, running){
	this.tires = tires;
	this.colour = colour;
	this.doors = doors;
	this.running = running;
	this.getStatus = function(){
		return this.running;
	};
};

var Lowrider = function(){
	this.axle = axles;
	this.bounce = function(){
		return 'bounce boucne bounce';
	};
};

Lowrider.prototype = new Car(4, 'black', 4, true);

var beetle = new Car(4, "red", 5, false);
var currentStatus = beetle.getStatus();

//console.log(currentStatus);

var lowRiderVonOlaf = new Lowrider();
var lowRiderVonAngelo = new Lowrider();

console.log(lowRiderVonAngelo.bounce());
console.log(lowRiderVonOlaf.bounce());




function myFunction(firstParam, secondParam, thirdParam, fourthParam){
	console.log(thirdParam);
	console.log(fourthParam);

	return "hello";
}

console.log(myFunction(2,4));

*/


/*

var funcA = function(){console.log("Hallo");};
funcA();

var funcB = [function(){console.log("Aufruf!");}];
funcB[0]();

var funcC = {
	method1 : function(){
		console.log("Methode!");
	}
};
funcC.method1();
funcC['method1']();


var funcD = function(func){
	return func;
};

var runFunctionPassedToFunc = funcD(function(){console.log("Hi");});

runFunctionPassedToFunc();



var funcE = function(){};

funcE.color = 'green';

console.log(funcE.color);




var add = function(x, y){
	if(typeof x !== 'number' || typeof y !== 'number') {
		return 'Bitte nur Zahlen angeben';
	}
	return x+y;
};

console.log(add(2,3));
console.log(add(2,'5'));



// Function expression
var func1 = function(x,y){
	console.log(this);
};

// Function Statement
function func1a(x,y){
	console.log(this);
}

// Function Constructor
var funcConstructor = new Function('x', 'y', 'console.log("Hallo");');
funcConstructor();

console.log(func1(2,4));


// Invoke Functions

// Function Pattern
var myFunction = function(){console.log("Hi");};
myFunction();

// Method Pattern
var myObject = {
	myMethod : function(){
		console.log("Helloooo");
	}
};
myObject.myMethod();


// Constructor Pattern
var Stefan = function(){
	this.living = true;
	this.age = 26;
	this.gender = 'male';
	this.getGender = function(){
		return this.gender;
	};
};

var stefan = new Stefan();

// apply() und call() pattern
var myObject = {
	myMethod : function(){
		console.log(this.name, arguments[0], arguments[1]);
	}
};

var stefan = {name: "stefan"};
var caro = {name: "caro"};

myObject.myMethod.call(stefan, 'foo', 'bar');
myObject.myMethod.apply(stefan, ['foo', 'bar']);



// Exceptions
var add = function(a,b){
	if(typeof a !== 'number' || typeof b !== 'number') {
		throw {
			name: 'TypeError',
			message: 'Bitte nur Zahlen angeben'
		};
	}
	return a+b;
};

var try_it = function(){
	try {
		add();
	} catch(e){
		console.log(e.name + ': ' + e.message);
	}
};

try_it();




// Anonyme Function
var sayHi = function(f){
	f();
};

sayHi(function(){console.log("Hi");});


// Selbstaufrufende Funktionen
var sagWas = function(){
	console.log('Was!');
}();

// GEHT NICHT!:
function sagWas(){
	console.log("WAT");
}();


// Anonyme selbstaufrufende Funktionen

(function(message){
	console.log(message);
})('Hallo');



var foo = function(){
	var bar = function(){
		var goo = function(){
			console.log(this);
		}();
	}();
}();


// Hoisted functions

sayWhat();

function sayWhat(){
	console.log("WHAT");
}



var myObject = {
	func1 : function(){
		// Loggt myObject
		console.log(this);
		var func2 = function(){
			// Loggt Window Object
			console.log(this);
			var func3 = function(){
				// Loggt Window Object 
				console.log(this);
			}();
		}();
	}
};

myObject.func1();


var myObject = {
	func1 : function(){
		// Loggt myObject
		console.log(this);
		var that = this;
		var func2 = function(){
			// Loggt myObject
			console.log(that);
			var func3 = function(){
				// Loggt Window Object 
				console.log(that);
			}();
		}();
	}
};

myObject.func1();


var foo = function(){
	var boo = function(){
		var bar = 2;
	}();
}();

console.log(bar);



var func1 = function(){
	var sayHiText = "howdy";
	var func2 = function(){
		console.log(sayHiText);
	}();
}();



var x = 10;
var foo = function(){
	var x = 20;
	var bar = function(){
		var x = 30;
		console.log(x);
	}();
}();



var parentFunction = function(){
	var foo = 'foo';
	return function(){
		console.log(foo);
	};
};

var nestedFunction = parentFunction();
nestedFunction();


var countUpFromZero = function(){
	var count = 0;
	return function(){
		return ++count;
	};
}();

console.log(countUpFromZero());
console.log(countUpFromZero());
console.log(countUpFromZero());
console.log(countUpFromZero());
console.log(countUpFromZero());
console.log(countUpFromZero());


*/


var quo = function(status){
	return {
		get_status: function(){
			return status;
		}
	};
};

var myQuo = quo('toll');
console.log(myQuo.get_status());











































