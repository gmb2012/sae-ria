function createCORSRequest(method, url){
	var xhr = new XMLHttpRequest();

	// XHR für Chrome, Safari, Firefox, Opera
	if("withCredentials" in xhr){
		xhr.open(method, url);
	} else if(typeof XDomainRequest != "undefined"){
		xhr = new XDomainRequest();
		xhr.open(method, url);
	} else {
		// CORS wird nicht unterstützt vom Browser
		xhr = null;
	}
	return xhr;
}

function makeCorsRequest(){
	var url = "http://sae.feelleicht.com/call-cors.php";
	var xhr = createCORSRequest('GET', url);
	if(!xhr){
		alert("Cors not supported");
	}

	xhr.onload = function(){
		var text = xhr.responseText;
		alert("Antwort vom Server;" + text);
	}

	xhr.onerror = function(){
		alert("Oops, da hat die Verbindung nicht geklappt");
	}

	xhr.send();
}

makeCorsRequest();
