<?php

	header("Access-Control-Allow-Origin: http://sfeser.sculptor.uberspace.de");
    $meinArray = array("Vorname" => "Stefan", "Nachname" => "Feser");

    $jsonData = json_encode($meinArray);

    print $jsonData;

?>