<?php

    $meinArray = array("Vorname" => "Stefan", "Nachname" => "Feser");

    $jsonData = json_encode($meinArray);

    print $jsonData;

?>