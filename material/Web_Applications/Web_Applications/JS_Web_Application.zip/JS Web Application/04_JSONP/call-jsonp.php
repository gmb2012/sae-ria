<?php
	if(isset($_GET["callback"]) && !empty($_GET["callback"])){
		$callback = $_GET["callback"];

		$ip = $_SERVER["REMOTE_ADDR"];
		$nachricht = "Ihre IP-ADresse lautet: " . $ip;

		header("Content-Type: application/javascript");

		print $callback . "('".$nachricht."')";
	}
?>